//
//  ViewController.swift
//  K
//
//  Created by Sonoda Seiya on 2014/11/27.
//  Copyright (c) 2014年 Sonoda Seiya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

