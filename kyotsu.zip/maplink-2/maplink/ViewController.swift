//
//  ViewController.swift
//  maplink
//
//  Created by Tatsuki Oyakawa on 2015/01/10.
//  Copyright (c) 2015年 Tatsuki Oyakawa. All rights reserved.
//

import UIKit

var urlString = "https://www.google.co.jp/maps/place/%E3%80%92901-2424+%E6%B2%96%E7%B8%84%E7%9C%8C%E4%B8%AD%E9%A0%AD%E9%83%A1%E4%B8%AD%E5%9F%8E%E6%9D%91%E5%8D%97%E4%B8%8A%E5%8E%9F+%E5%85%B1%E9%80%9A%E6%95%99%E8%82%B2%E6%A3%9F/@26.2479691,127.7678051,18z/data=!4m5!1m2!2m1!1z55CJ55CD5aSn5a2m44CA5YWx6YCa5pWZ6IKy5qOf!3m1!1s0x34e56d025e73acc3:0xea9b0d0607d0764a?hl=ja"
var url = NSURL(string: urlString)

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func MapURL(sender: AnyObject) {
        if UIApplication.sharedApplication().canOpenURL(url!){
            UIApplication.sharedApplication().openURL(url!)
        }
        }
}